<?php
echo "<div id=\"menu\">";
echo "<h3><a href=\"\CST8238\Lab6\index.php\">Index</a> &middot; <a href=\"\CST8238\Lab6\DivideByThree.php\">DivideByThree</a>  &middot; 
		<a href=\"\CST8238\Lab6\Random.php\">Random</a> &middot; <a href=\"\CST8238\Lab6\Pattern.php\">Pattern</a>";
echo "</div>";
?>