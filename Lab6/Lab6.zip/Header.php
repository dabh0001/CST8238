<?php
echo "<div id=\"header\">";
echo "<h1>Computer Engineering Technology &#45 Computing Science</h1>";
echo "<h1>CST8238: Web Programming</h1>";
echo "</div>";
?>