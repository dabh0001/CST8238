<?php
echo "<div id=\"footer\">";
echo "<h5>&copy; Student Number: 040902920, Name: Aditya Dabhi, E-Mail: dabh0001@algonquinlive.com</h5>";
echo "</div>";
?>