<!doctype html>
<html>
<head>
	<title>Lab 6: Index</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css"/>
</head>

<body>
	
	<?php include "Header.php";?>
	
	<?php include "Menu.php";?>
	
	<div class="content">
	
	<?php
	$space = "&nbsp;&nbsp;";
	for ($i = 1; $i <= 6; $i++) {
		for ($j = $i; $j < 6; $j++){
			echo $space;
		}
		for ($k = 1; $k < ($i*2); $k++) {
			echo "*";
		}
		echo "<br>";
	}
	
	for ($i = 6; $i >= 1 ; $i--) {
		for ($j = 6; $j > $i; $j--){
			echo $space;
		}
		for ($k = 1; $k < ($i*2); $k++) {
			echo "*";
		}
		echo "<br>";
	}
	?>
	
	<?php include "Footer.php";?>
	
</body>
</html>