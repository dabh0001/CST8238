<!DOCTYPE html>
<html>

	<style>

</style>		
                
				<header>
				<img src="images/header_img.jpg" alt="Dining Room" title="WP Eatery" />
            
				
				<div id="title">
                    <h1 >WP Eatery</h1>
                    <h2 align="center">1385 Woodroffe Ave, Ottawa ON</h2>
                    <h2>Tel: (613)727-4723</h2>
               </div>
            
				</header>
			
			
			      
                <div id="menuItems" align="center">
                   
				   <table border=4>
				   
				      <tr>
              <td><h1><a href="index.php">Home</a></h1></td>
              <td><h1><a href="menu.php">Menu</a></h1></td>
			  <td><h1><a href="contact.php">Contact</a></h1></td>
					</tr>
				   
				   </table>
				   
                </div>
				
			
			
			
			
			
         


</html>
