<!DOCTYPE html>
<html>
    <head>
        <title>WP Eatery - Menu</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href='http://fonts.googleapis.com/css?family=Fugaz+One|Muli|Open+Sans:400,700,800' rel='stylesheet' type='text/css' />
        <link href="css/style.css" rel="stylesheet" type="text/css">
    </head>
    <body>
	        
		<?php include "Header.php";?>

        <div id="wrapper">
    			
            <div id="content" class="clearfix">
                <p>&nbsp;</p>
                <h1>Coming Soon!</h1>
                <p>Thank you for visiting our menu. We will be posting our new menu in the very near future.</p>
            </div><!-- End Content -->	
        </div><!-- End Wrapper -->
		
		<?php include "Footer.php";?>
    </body>
</html>
