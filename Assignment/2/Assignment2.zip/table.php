<?php
echo "<table BORDERCOLOR=black>";
$temp=3;
for($i=2; $i<28; $i++){
    
    $foo=TRUE;
    
    for($j=2; $j<$i; $j++){
        
        if($i % $j == 0){
             
            $foo=FALSE;
            break;
            
        }
        
    }
    
	echo "<tr>";
    if($foo==TRUE){
        echo "<td>";
		echo $i;
		echo "</td>";
		echo "<td>";
		echo $temp."<br>";
		echo "</td>";
		$temp+=3;
		
	}
	echo "</tr>";
	
}
echo "</table>";

?>