<?php
	echo "<footer>";
		echo "<p>&copy; " . date("Y") .  " CST8285. All Rights Reserved.</p>";
    echo "</footer>";
?>