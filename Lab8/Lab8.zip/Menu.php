<?php
echo "<div id=\"menu\">";
echo "<h3><a href=\"\CST8238\Lab8\Input.php\">Input</a> &middot; <a href=\"\CST8238\Lab8\Session1.php\">Session1</a>  &middot; 
		<a href=\"\CST8238\Lab8\Session2.php\">Session2</a>";
echo "</div>";
?>