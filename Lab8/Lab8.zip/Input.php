<!doctype html>
<html>
<head>
	<title>Lab 8: Input</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css"/>
</head>

<body>
	
	<?php include "Header.php";?>
	
	<?php include "Menu.php";?>
	
	<div id="content">
	
		<div id="left">

			<form method="post">

				Employee Name <input type="text" name="employeeName" value="" /><br /><br />
				Employee ID <input type="text" name="employeeId" value="" /><br /> <br />
				Telephone Number <input type="text" name="telephoneNumber" value="" /> <br /><br />
				Email Address <input type="text" name="emailAddress" value="" /> <br /><br />
				Manager <input type="radio" name="Category" value="Manager">
				Team Lead<input type="radio" name="Category" value="Team Lead">
				IT Developer <input type="radio" name="Category" value="IT Developer">
				IT Analyst <input type="radio" name="Category" value="IT Analyst"> <br/><br />
				IT Projects:<select name="Projects">
								<option value="Nothing Selected">Please Select</option>
								<option value="Project A">Project A</option>
								<option value="Project B">Project B</option>
								<option value="Project C">Project C</option>
								<option value="Project D">Project D</option>
							</select><br/><br />
				
				<input type="submit" />
			
			</form>
		
		</div>



	
		<div id="right" >
				<?php
				
				if (isset ( $_POST ["employeeName"] ))
					$empName = $_POST ["employeeName"];
				else
					$empName = "";
				
				if (isset ( $_POST ["employeeId"] ))
					$id = $_POST ["employeeId"];
				else
					$id = "";
				
				if (isset ( $_POST ["telephoneNumber"] ))
					$phoneNumber = $_POST ["telephoneNumber"];
				else
					$phoneNumber = "";
				
				if (isset ( $_POST ["emailAddress"] ))
					$emailaddr = $_POST ["emailAddress"];
				else
					$emailaddr = "";
				
				if (isset ( $_POST ["Category"] ))
					$School = $_POST ["Category"];
				else
					$School = "";
				
				if (isset ( $_POST ["Projects"] ))
					$Projects = $_POST ["Projects"];
				else
					$Projects = "";
				?>
	
		
		<?php
		echo "<table align='left' height='60%'>";
		echo "<tr><td>First Name: " . $empName . "</td></tr>";
		echo "<tr><td>Last Name: " . $id . "</td></tr><br/>";
		echo "<tr><td>Telephone Number: " . $phoneNumber . "</td></tr>";
		echo "<tr><td>Email: " . $emailaddr . "</td></tr>";
		echo "<tr><td>Status: " . $School. "</td></tr>";
		echo "<tr><td>Project: " . $Projects . "</td></tr>";
		echo "</table>";
		?>
		</div>
		
	</div>

	<?php include "Footer.php";?>

</body>
</html>