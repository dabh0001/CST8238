		
		
			<?php
			session_start ();
			
			if (isset ( $_POST ["submit"] )) {
				
				$_SESSION ["empName"] = $_POST ["employeeName"];
				$_SESSION ["id"] = $_POST ["employeeId"];
				$_SESSION ["phoneNumber"] = $_POST ["telephoneNumber"];
				$_SESSION ["emailaddr"] = $_POST ["emailAddress"];
				$_SESSION ["Category"] = $_POST ["Category"];
				$_SESSION ["Projects"] = $_POST ["Projects"];
				
				header ( "Location:Session2.php" );
				exit;
			}
			
			?>

<!doctype html>
<html>
<head>
	<title>Lab 8: Session1</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css"/>
</head>

<body>

<?php include "Header.php"; ?>
<?php include "Menu.php"; ?>


<div id="content">
		<div class="middle">

			<form method="post" action="Session2.php">
				
				
				Employee Name <input type="text" name="employeeName" value="" /><br /><br />
				Employee ID <input type="text" name="employeeId" value="" /><br /> <br />
				Telephone Number <input type="text" name="telephoneNumber" value="" /> <br /><br />
				Email Address <input type="text" name="emailAddress" value="" /> <br /><br />
				Manager <input type="radio" name="Category" value="Manager">
				Team Lead<input type="radio" name="Category" value="Team Lead">
				IT Developer <input type="radio" name="Category" value="IT Developer">
				IT Analyst <input type="radio" name="Category" value="IT Analyst"> <br/><br />
				IT Projects:<select name="Projects">
								<option value="Nothing Selected">Please Select</option>
								<option value="Project A">Project A</option>
								<option value="Project B">Project B</option>
								<option value="Project C">Project C</option>
								<option value="Project D">Project D</option>
							</select><br/><br />
				
				<input type="submit" value ="Submit Information" />
			</form>
		</div>
	</div>

<?php include "Footer.php"; ?>
</body>

</html>