<!doctype html>
<html>
<head>
	<title>Lab 8: Session2</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css"/>
</head>

<body>
		
		<?php include "Header.php"; ?>
		<?php include "Menu.php"; ?>

	<div id="content">
		
		<?php
		
		
		session_start ();
		
		$_SESSION ["empName"] = $_POST ["employeeName"];
		$_SESSION ["id"] = $_POST ["employeeId"];
		$_SESSION ["phoneNumber"] = $_POST ["telephoneNumber"];
		$_SESSION ["emailaddr"] = $_POST ["emailAddress"];
		$_SESSION ["Category"] = $_POST ["Category"];
		$_SESSION ["Projects"] = $_POST ["Projects"];
		
		if (isset ( $_SESSION ["empName"] )) {
			echo "<b>First Name: </b>" . $_SESSION ['empName'];
			echo "<br />";
		} 
		if (isset ( $_SESSION ["id"] )) {
			echo "<b>Last Name: </b>" . $_SESSION ['id'];
			echo "<br />";
		} 
		if (isset ( $_SESSION ["phoneNumber"] )) {
			echo "<b>Phone Number : </b>" . $_SESSION ['phoneNumber'];
			echo "<br />";
		} 
		if (isset ( $_SESSION ["emailaddr"] )) {
			echo "<b>Email : </b>" . $_SESSION ['emailaddr'];
			echo "<br />";
		} 
		if (isset ( $_POST ["Category"] )) {
			echo "<b>Type: </b>" . $_SESSION ['Category'];
			echo "<br />";
		} 
		
			if (isset ( $_POST ["Projects"] )) {
				echo "<b>Game: </b>" . $_SESSION ['Projects'];
				echo "<br />";
			}
			
		?>
		
		</div>
		 <?php include "Footer.php"; ?>  
	</body>
</html>