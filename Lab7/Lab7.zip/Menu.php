<?php
echo "<div id=\"menu\">";
echo "<h3><a href=\"\CST8238\Lab7\Array1.php\">Array1</a> &middot; <a href=\"\CST8238\Lab7\Array2.php\">Array2</a>  &middot; 
		<a href=\"\CST8238\Lab7\Object.php\">Object</a>";
echo "</div>";
?>