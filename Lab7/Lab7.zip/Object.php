<!doctype html>
<html>
<head>
	<title>Lab 7: Object</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css"/>
	
</head>

<body>
	<?php include "Header.php";?>
	
	<?php include "Menu.php";?>
	
	<div class="content">
	
	<?php	
		
		interface Employee{
			public function displayEmployeeInfo();
		}
		
		class Management implements Employee{
			protected $sin;
			protected $age;
			protected $salary;
			
			function __construct($sin, $age, $salary){
				$this ->sin = $sin;
				$this ->age = $age;
				$this ->salary = $salary;
			}
			
			public function displayEmployeeInfo(){
				return "SIN: " . $this->sin . ", age: " . $this->age . ", salary: " . $this->salary;
			}
		}
		
		class Manager extends Management {
			private $adminLevel;
			function __construct($sin, $age, $salary, $adminLevel) {
				parent::__construct ($sin, $age, $salary);
				$this->adminLevel = $adminLevel;
			}
			
			public function displayEmployeeInfo(){
				return parent::displayEmployeeInfo() . ", Admin Level: " . $this->adminLevel . "<br/>";
			}
		}
		
		echo "<h2><b><u>Manager</u></b></h2><br/>";

		
		$manage = new Manager (123456789,45,110000,"MG-06");
		echo $manage -> displayEmployeeInfo();
		$manage = new Manager (987654321,55,120000,"MG-07");
		echo $manage -> displayEmployeeInfo();
		
		echo "<br/>";
		echo "<br/>";
		
		class Development implements Employee{
			protected $sin;
			protected $age;
			protected $salary;
			
			function __construct($sin, $age, $salary){
				$this ->sin = $sin;
				$this ->age = $age;
				$this ->salary = $salary;
			}
			
			public function displayEmployeeInfo(){
				return "SIN: " . $this->sin . ", age: " . $this->age . ", salary: " . $this->salary;
			}
		}
		
		class ITSpecialist extends Development {
			private $projectAssigned;
			function __construct($sin, $age, $salary, $projectAssigned) {
				parent::__construct ($sin, $age, $salary);
				$this->projectAssigned = $projectAssigned;
			}
			
			public function displayEmployeeInfo(){
				return parent::displayEmployeeInfo() . ", Assigned Project: " . $this->projectAssigned . "<br/>";
			}
		}
		
		echo "<h2><b><u>ITSpecialist</u></b></h2><br/>";
				
		$special = new ITSpecialist (567451234,35,100000,"T1SR");
		echo $special -> displayEmployeeInfo();
		$special = new ITSpecialist (234451234,20,90000,"HIMS");
		echo $special -> displayEmployeeInfo();
		
		echo "<br/>";
		echo "<br/>";

	?>
	
	</div>

	<?php include "Footer.php"; ?>

</body>
</html>