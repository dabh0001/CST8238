<!doctype html>
<html>
<head>
	<title>Lab 7: Array1</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css"/>
</head>

<body>
	
	<?php include "Header.php";?>
	
	<?php include "Menu.php";?>
	
	<div class="content">
	
	<?php
	
	$calendar = array("January", "Febuary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        print_r($calendar);
    ?>
      
	  <h1>FOR loop</h1>
      
	<?php
    for ($x=0; $x<count($calendar); $x++)
		{
			$num = $x+1;
			echo "Month $num: $calendar[$x]";
			echo "<br>";
		}
		echo "<br>";
        echo "<br>";
        echo "<br>";
    ?>

    <h1>FOREACH loop</h1>
	
	<?php
		$num=1;
        foreach ($calendar as &$month)
        {
			echo "Month $num: $month";
			$num++;
			echo "<br>";
        }
        echo "<br>";
        echo "<br>";
        echo "<br>";
    ?>

    <h1>WHILE loop, SWITCH statement</h1>
    
	<?php
        $x = 0;
        while ($x < 12)
        {
          $num = $x + 1;
          switch ($x)
          {
            case 0:
              echo "Month $num: $calendar[$x] has 31 days";
              break;
            case 1:
              echo "Month $num: $calendar[$x] has 28, or 29 days";
              break;
            case 2:
              echo "Month $num: $calendar[$x] has 31 days";
              break;
            case 3:
              echo "Month $num: $calendar[$x] has 30 days";
              break;
            case 4:
              echo "Month $num: $calendar[$x] has 31 days";
              break;
            case 5:
              echo "Month $num: $calendar[$x] has 30 days";
              break;
            case 6:
              echo "Month $num: $calendar[$x] has 31 days";
              break;
            case 7:
              echo "Month $num: $calendar[$x] has 30 days";
              break;
            case 8:
              echo "Month $num: $calendar[$x] has 31 days";
              break;
            case 9:
              echo "Month $num: $calendar[$x] has 30 days";
              break;
            case 10:
              echo "Month $num: $calendar[$x] has 30 days";
              break;
            case 11:
              echo "Month $num: $calendar[$x] has 31 days";
              break;
          }
          echo "<br>";
          $x++;
        }
      ?>
	  
	</div>

	<?php include "Footer.php";?>

</body>
</html>