<!doctype html>
<html>
<head>
	<title>Lab 7: Array2</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css"/>
	<style>
	
	table, th, td {
	border: 1px solid black;
	border-collapse: collapse;
	}
	</style>
</head>

<body>
	
	<?php include "Header.php";?>
	
	<?php include "Menu.php";?>
	
	<div class="content">
	
	<?php
	
	$Product=array(
					"Printer" => array(
									"Brand" => "Epson",
									"Quantity" => "100",
									"Price" => "2500"
									),
					
								array(
									"Brand" => "Canon",
									"Quantity" => "100",
									"Price" => "3000"
									),
					
								array(
									"Brand" => "Xerox",
									"Quantity" => "500",
									"Price" => "2000"
									),
									
					"Laptop" => array(
									"Brand" => "Apple",
									"Quantity" => "200",
									"Price" => "2000"
									),
					
								array(
									"Brand" => "HP",
									"Quantity" => "300",
									"Price" => "1500"
									),
					
								array(
									"Brand" => "Toshiba",
									"Quantity" => "100",
									"Price" => "1200"
									),
									
					"TV" => array(
									"Brand" => "Samsung",
									"Quantity" => "500",
									"Price" => "1200"
									),
					
								array(
									"Brand" => "LG",
									"Quantity" => "500",
									"Price" => "1050"
									),
					
								array(
									"Brand" => "Sony",
									"Quantity" => "200",
									"Price" => "1000"
									)
				);					
					
	
	?>
	
	<?php
	
	var_dump($Product);
	echo "<br>";
    echo "<br>";
    echo "<br>";
	
	?>
	
	<?php
	
	$x=1;
	foreach($Product as $Product){
		if($x=="1"){
		echo "<u><b>Printer</b></u><br>";
		}
		elseif($x=="4"){
		echo "<u><b>Laptop</b></u><br>";
		}
		elseif($x=="7"){
		echo "<u><b>TV</b></u><br>";
		}
		foreach($Product as $key => $value){
			
			echo "$key";
			echo " : ";
			echo "$value";
			echo "<br>";
			
		}
		$x++;
		echo "<br>";
		echo "<br>";
		echo "<br>";
	}
	
	?>
	
	<?php
	$Product=array(
					"Printer" => array(
									"Brand" => "Epson",
									"Quantity" => "100",
									"Price" => "2500"
									),
					
								array(
									"Brand" => "Canon",
									"Quantity" => "100",
									"Price" => "3000"
									),
					
								array(
									"Brand" => "Xerox",
									"Quantity" => "500",
									"Price" => "2000"
									),
									
					"Laptop" => array(
									"Brand" => "Apple",
									"Quantity" => "200",
									"Price" => "2000"
									),
					
								array(
									"Brand" => "HP",
									"Quantity" => "300",
									"Price" => "1500"
									),
					
								array(
									"Brand" => "Toshiba",
									"Quantity" => "100",
									"Price" => "1200"
									),
									
					"TV" => array(
									"Brand" => "Samsung",
									"Quantity" => "500",
									"Price" => "1200"
									),
					
								array(
									"Brand" => "LG",
									"Quantity" => "500",
									"Price" => "1050"
									),
					
								array(
									"Brand" => "Sony",
									"Quantity" => "200",
									"Price" => "1000"
									)
				);					
	echo "<table>";	
	$x=1;
	
	
		echo "<tr>";	
				echo "<th>Category</th>";
				echo "<th>Brand</th>";
				echo "<th>Quantity</th>";
				echo "<th>Price</th>";
		echo "</tr>";
		
		foreach($Product as $Product){
		echo "<tr>";
		
			if($x==1){
				echo "<td>Printer</td>";
			}
			else
				if($x==10){
				echo "<td>Laptop</td>";
			}
			else
				if($x==19){
				echo "<td>TV</td>";
			}
			else
				echo "<td>&nbsp</td>";
			
			foreach((array)$Product as $key => $value){
			
				echo "<td>$value</td>";
			$x++;
			
		}	
		echo "</tr>";
		
		}
	echo "</table>";
	
?>
	
	
	</div>

	<?php include "Footer.php"; ?>

</body>
</html>