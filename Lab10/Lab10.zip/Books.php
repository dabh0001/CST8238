<?php

$q=$_GET["q"];

$y="";

$xml = file_get_contents( "http://www.rejaul.com/CST8238/Lab10/Books.xml" );

$xmlDoc = new DOMDocument();
$xmlDoc->loadXML($xml);

$book = $xmlDoc->getElementsByTagName('book');

foreach($book as $currentbook)
{
	foreach($currentbook->childNodes as $node)
	{
		if ($node->nodeName == "genre")
	 	{
	 		if ($node->nodeValue==$q)
	 		{
	 			$y=($node->parentNode); 
				echo("<br>");
				foreach($y->childNodes as $node)
{
	
	if ($node->nodeName == "author")
	{
		echo("<b>" . $node->nodeName . ":</b> ");
		echo($node->nodeValue);
		echo("<br>");
	}
	
	if ($node->nodeName == "title")
	{
		echo("<b>" . $node->nodeName . ":</b> ");
		echo($node->nodeValue);
		echo("<br>");
	}

	if ($node->nodeName == "genre")
	{
		echo("<b>" . $node->nodeName . ":</b> ");
		echo($node->nodeValue);
		echo("<br>");
	}		 
	 
	if ($node->nodeName == "price")
	{
		echo("<b>" . $node->nodeName . ":</b> ");
		echo($node->nodeValue);
		echo("<br>");
	}
		
	if ($node->nodeName == "publish_date")
	  {
		echo("<b>" . $node->nodeName . ":</b> ");
		echo($node->nodeValue);
		echo("<br>");
	  }

	if ($node->nodeName == "description")
	{
		echo("<b>" . $node->nodeName . ":</b> ");
		echo($node->nodeValue);
		echo("<br>");
	}
}
				
		echo("<br>");			
				
				
				
				
				
				
				
				
				
				
				
				
				
	 		
	 	 	}
	 	}

	}
}


		
?>